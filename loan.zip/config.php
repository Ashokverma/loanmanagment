<?php
define("DB_HOST", "127.0.0.1");
define("DB_DNAME","loan_master");   // Database name
define("DB_USER","root");
define("DB_PASS","");
define("DB_CHRST","utf8");
define("DEBUG_STATUS",true);
define("FILENAME_SEPARATOR",";");
?>